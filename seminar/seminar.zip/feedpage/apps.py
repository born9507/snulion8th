from django.apps import AppConfig


class FeedpageConfig(AppConfig):
    name = 'feedpage'
